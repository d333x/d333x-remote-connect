import subprocess
import shlex

class CommandHandler:
    @staticmethod
    def execute(cmd: str) -> bytes:
        try:
            result = subprocess.check_output(
                shlex.split(cmd),
                stderr=subprocess.STDOUT,
                shell=True,
                timeout=10
            )
            return result
        except subprocess.CalledProcessError as e:
            return f"Error: {e.output}".encode()
        except Exception as e:
            return f"Fatal error: {str(e)}".encode()