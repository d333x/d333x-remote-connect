import socket
import threading
from cryptography.fernet import Fernet

class NetworkCore:
    def __init__(self, port=33333):
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clients = {}
    
    def start_server(self):
        self.sock.bind(('0.0.0.0', self.port))
        self.sock.listen(100)
        threading.Thread(target=self._accept_connections).start()
    
    def _accept_connections(self):
        while True:
            conn, addr = self.sock.accept()
            self.clients[addr[0]] = conn
            threading.Thread(target=self._handle_client, args=(conn,)).start()
    
    def _handle_client(self, conn):
        try:
            while True:
                data = conn.recv(1024)
                if not data: break
                response = self.process_command(data)
                conn.send(response)
        except:
            conn.close()
    
    def process_command(self, data: bytes) -> bytes:
        return b"Command processed"