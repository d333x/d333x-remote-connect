from cryptography.fernet import Fernet
import base64

class CryptoSystem:
    def __init__(self):
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)
    
    def encrypt(self, data: bytes) -> bytes:
        return self.cipher.encrypt(data)
    
    def decrypt(self, encrypted: bytes) -> bytes:
        return self.cipher.decrypt(encrypted)
    
    def save_key(self, path: str):
        with open(path, 'wb') as f:
            f.write(base64.b64encode(self.key))
    
    def load_key(self, path: str):
        with open(path, 'rb') as f:
            self.key = base64.b64decode(f.read())
        self.cipher = Fernet(self.key)