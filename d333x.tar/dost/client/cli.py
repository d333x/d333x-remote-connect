import cmd
from scanner import NetworkScanner
import socket

class D333XClient(cmd.Cmd):
    prompt = 'd333x> '
    
    def __init__(self):
        super().__init__()
        self.scanner = NetworkScanner()
        self.current_conn = None
    
    def do_scan(self, args):
        """Сканировать сеть: scan 192.168.1.0/24"""
        self.scanner.scan(args)
        for ip, status in self.scanner.get_nodes().items():
            print(f"{ip}: {status.upper()}")
    
    def do_connect(self, ip):
        """Подключиться к узлу: connect 192.168.1.5"""
        try:
            self.current_conn = socket.socket()
            self.current_conn.connect((ip, 33333))
            print(f"Connected to {ip}")
        except:
            print("Connection failed")
    
    def do_exec(self, cmd):
        """Выполнить команду: exec 'whoami'"""
        if self.current_conn:
            self.current_conn.send(cmd.encode())
            print(self.current_conn.recv(1024).decode())
    
    def do_exit(self, _):
        """Выйти из системы"""
        return True

if __name__ == "__main__":
    D333XClient().cmdloop()