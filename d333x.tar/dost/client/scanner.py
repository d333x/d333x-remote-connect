import socket
from ipaddress import IPv4Network
from concurrent.futures import ThreadPoolExecutor

class NetworkScanner:
    def __init__(self):
        self.active_nodes = {}
    
    def scan(self, subnet="192.168.1.0/24"):
        network = IPv4Network(subnet)
        with ThreadPoolExecutor(max_workers=100) as executor:
            for ip in network.hosts():
                executor.submit(self._check_node, str(ip))
    
    def _check_node(self, ip):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(2)
                s.connect((ip, 33333))
                s.send(b'PING')
                if s.recv(4) == b'PONG':
                    self.active_nodes[ip] = 'online'
        except:
            self.active_nodes[ip] = 'offline'
    
    def get_nodes(self):
        return self.active_nodes