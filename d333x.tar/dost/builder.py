import PyInstaller.__main__
import os
import shutil

# Кроссплатформенный разделитель
SEP = ";" if os.name == "nt" else ":"

PyInstaller.__main__.run([
    "server/main.py",
    "--onefile",
    "--noconsole",
    "--icon=data/icon.ico",
    "--name=DocumentViewer.exe",
    f"--add-data=data/icon.ico{SEP}data",  # Исправленная строка
    "--hidden-import=winreg,cryptography",
    "--clean"
])

# Очистка временных файлов
shutil.rmtree("build", ignore_errors=True)
shutil.rmtree("__pycache__", ignore_errors=True)