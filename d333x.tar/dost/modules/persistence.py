import sys
import os

class PersistenceManager:
    def __init__(self):
        if sys.platform == 'win32':
            self._windows_persistence()
        else:
            self._linux_persistence()

    def _windows_persistence(self):
        try:
            import winreg  # Импорт только для Windows
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run")
            winreg.SetValueEx(key, "MyApp", 0, winreg.REG_SZ, sys.argv[0])
            winreg.CloseKey(key)
        except ImportError:
            pass

    def _linux_persistence(self):
        # Реализация для Linux/Android (Termux)
        cron_job = f"@reboot python3 {os.path.abspath(__file__)}"
        os.system(f'(crontab -l 2>/dev/null; echo "{cron_job}") | crontab -')